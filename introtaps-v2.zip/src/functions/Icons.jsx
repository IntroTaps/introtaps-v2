function Bi ({ i, s }) {
   return <i className={`bi bi-${i} ${s}`} />
}
export default Bi