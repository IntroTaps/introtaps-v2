function Bif ({ i, s }) {
   return <i className={`bi bi-${i}-fill ${s}`} />
}
export default Bif;